class RenameLocationsCoursesToCoursesLocations < ActiveRecord::Migration[5.0]
  def change
    rename_table :locations_courses, :courses_locations
  end
end
