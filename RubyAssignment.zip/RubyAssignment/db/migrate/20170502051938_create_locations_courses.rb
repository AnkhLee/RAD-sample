class CreateLocationsCourses < ActiveRecord::Migration[5.0]
  def change
    create_table :locations_courses do |t|
      t.integer :course_id, null: false
      t.integer :location_id, null: false
    end
  end
end
