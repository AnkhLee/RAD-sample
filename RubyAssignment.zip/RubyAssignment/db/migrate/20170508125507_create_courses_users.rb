class CreateCoursesUsers < ActiveRecord::Migration[5.0]
  def change
    create_table :courses_users do |t|
      t.integer :course_id, null: false
      t.integer :user_id, null: false
    end
  end
end
