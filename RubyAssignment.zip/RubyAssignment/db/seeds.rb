# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)



Category::HABTM_Courses.create!([
  {course_id: 1, category_id: 1},
  {course_id: 2, category_id: 1},
  {course_id: 3, category_id: 2},
  {course_id: 4, category_id: 3}
])
Course::HABTM_Locations.create!([
  {course_id: 1, location_id: 1},
  {course_id: 1, location_id: 3},
  {course_id: 2, location_id: 2},
  {course_id: 2, location_id: 3},
  {course_id: 3, location_id: 1},
  {course_id: 3, location_id: 4},
  {course_id: 4, location_id: 4}
])
Course::HABTM_Categories.create!([
  {course_id: 1, category_id: 1},
  {course_id: 2, category_id: 1},
  {course_id: 3, category_id: 2},
  {course_id: 4, category_id: 3}
])
Location::HABTM_Courses.create!([
  {course_id: 1, location_id: 1},
  {course_id: 1, location_id: 3},
  {course_id: 2, location_id: 2},
  {course_id: 2, location_id: 3},
  {course_id: 3, location_id: 1},
  {course_id: 3, location_id: 4},
  {course_id: 4, location_id: 4}
])
Category.create!([
  {title: "Web Development"},
  {title: "Programming Tech."},
  {title: "Database"},
  {title: "Software Engineering"}
])
Contact.create!([
  {name: "Mike Dude", email: "mike.dude@rmit.edu.au", message: "Hello! Have a nice day. I think the website is awesome!"},
  {name: "Shahe She", email: "shahe.she@rmit.edu.au", message: "Ohm! I just got 404 error! what was going on :("},
  {name: "Masu Pilami", email: "masu.pilami@rmit.edu.au", message: "Hey I cant sign up using my student account. Please help!"},
  {name: "Anna Bell", email: "anna.bell@rmit.edu.au", message: "Hello, I am beautiful Anna."}
])
Course.create!([
  {title: "Web Database App.", prerequisite: "Web Prog., DB Concept", madeon: "2019-04-14 01:19:00", like: 5, dislike: 1, imagepath: "website1.jpg", user_id: 33, description: nil},
  {title: "Rapid App. Development", prerequisite: "Web Programming", madeon: "2019-04-14 01:25:00", like: 9, dislike: 2, imagepath: "website1.jpg", user_id: 34, description: nil},
  {title: "Adv. Programming Tec.", prerequisite: "Java Programming", madeon: "2019-04-14 01:30:00", like: 3, dislike: 2, imagepath: "website1.jpg", user_id: 34, description: nil},
  {title: "Database Concept", prerequisite: "Basic computer literacy", madeon: "2019-04-14 01:31:00", like: 1, dislike: 2, imagepath: "website1.jpg", user_id: 35, description: nil}
])
Location.create!([
  {address: "14.10.30"},
  {address: "14.10.31"},
  {address: "12.09.15"},
  {address: "10.06.27"}
])
User.create!([
  {name: "Harry Potter", email: "harry.potter@rmit.edu.au", password_digest: "$2a$10$WSE4WqoDx0mlC/1TJr4Tsu6QQk0Ln.r2qjwpzurKHyLiP8JiN/ut."},
  {name: "Hermione Granger", email: "hermione.granger@rmit.edu.au", password_digest: "$2a$10$fU5n2CFrUi.x0wGaaqbkx.KWO/8fKtT7MAm7.9rwVzNTBH8e/kg9i"},
  {name: "Ron Weasley", email: "ron.weasley@rmit.edu.au", password_digest: "$2a$10$p6lX7DoBo0pRwWVHd.iEkO5lJfbchYjbU03DGoUH.N5Stsg0DRKBG"},
  {name: "Sample User", email: "sample.user@rmit.edu.au", password_digest: "$2a$10$HlhC05ardrL5UpqGbnFNEut./27GIPRhdLHAYiPgzo7wIfD2JRR7a"}
])
