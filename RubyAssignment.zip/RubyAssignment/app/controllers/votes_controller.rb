class VotesController < ApplicationController
  before_action :get_course

  def upvote
    data = Hash.new
    data[:title] = @course.title
    data[:prerequisite] = @course.prerequisite
    data[:madeon] = @course.madeon
    data[:like] = @course.like + 1
    data[:dislike] = @course.dislike
    data[:imagepath] = @course.imagepath
    data[:user_id] = @course.user_id

    if @course.update data
      if request.env['HTTP_REFERER'].present? and request.env['HTTP_REFERER'] != request.env['REQUEST_URI']
        redirect_to :back
      else
        redirect_to default
      end
      flash[:success] = 'You have voted for the course.'
    else
      if request.env['HTTP_REFERER'].present? and request.env['HTTP_REFERER'] != request.env['REQUEST_URI']
        redirect_to :back
      else
        redirect_to default
      end
      flash[:notice] = 'Server went wrong... Try again later.'
    end
  end

  def downvote
    data = Hash.new
    data[:title] = @course.title
    data[:prerequisite] = @course.prerequisite
    data[:madeon] = @course.madeon
    data[:like] = @course.like
    data[:dislike] = @course.dislike + 1
    data[:imagepath] = @course.imagepath
    data[:user_id] = @course.user_id

    if @course.update data
      if request.env['HTTP_REFERER'].present? and request.env['HTTP_REFERER'] != request.env['REQUEST_URI']
        redirect_to :back
      else
        redirect_to default
      end
      flash[:success] = 'You have voted for the course.'
    else
      if request.env['HTTP_REFERER'].present? and request.env['HTTP_REFERER'] != request.env['REQUEST_URI']
        redirect_to :back
      else
        redirect_to default
      end
      flash[:notice] = 'Server went wrong... Try again later.'
    end
  end

  private

  def get_course
    @course = Course.find params[:id]
  end
end