require 'bcrypt'
class SessionsController < ApplicationController
  # GET /sessions/new
  def new
  end

  # POST /sessions
  def login
    if params[:type].nil?
      if params[:email].include?('@rmit.edu.au')
        user = User.find_by_email params[:email]

        if user && user.authenticate(params[:password])
          session[:user_id] = user.id
          redirect_to controller: 'users', action: 'show', id: user.id
        else
          redirect_to controller: 'sessions', action: 'new'
          flash[:notice] = 'Oops! That email and password combination does not match any records!'
        end
      else
        redirect_to controller: 'sessions', action: 'new'
        flash[:notice] = 'Check your email again. Only RMIT Staff can login. staff'
      end
    elsif params[:email].eql?('admin') && params[:password].eql?('password')
      session[:user_id] = 0
      redirect_to action: 'emails', controller: 'admin'
    else
      redirect_to controller: 'sessions', action: 'new'
      flash[:notice] = 'Check your email again. Only RMIT Staff can login. admin'
    end
  end

  # GET /sessions/destroy
  def destroy
    session[:user_id] = nil
    redirect_to root_path
  end

  def show
    session[:user_id] = nil
    redirect_to root_path
  end
end