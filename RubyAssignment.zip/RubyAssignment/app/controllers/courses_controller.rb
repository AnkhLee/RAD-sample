class CoursesController < ApplicationController
  before_action :get_user
  before_action :set_course, only: [:show, :edit, :update, :destroy]

  # GET /courses
  # GET /courses.json
  def index
    @courses = Course.all
  end

  # GET /courses/1
  # GET /courses/1.json
  def show
  end

  # GET /courses/new
  def new
    @course = Course.new
  end

  # GET /courses/1/edit
  def edit
  end

  def categories
    @course = Course.find params[:id]
    @categories = @course.categories
  end

  def locations
    @course = Course.find params[:id]
    @locations = @course.locations
  end

  # POST /courses
  # POST /courses.json
  def create
    errors = true
    filetypes = ['jpg', 'png', 'jpeg']
    if course_params[:title].length < 10 || course_params[:title].strip.empty?
      flash[:notice] = 'Course Title was either blank or too short. Required 10 or more letters long.'
    elsif course_params[:prerequisite].strip.empty?
      course_params[:prerequisite] = nil
    elsif course_params[:prerequisite].strip.length < 5
      flash[:notice] = 'Prerequisite was over abbreviated! Please make it meaningful to general visitors.'
    elsif course_params[:imagepath]
      if filetypes.any? { |type| course_params[:imagepath].original_filename.include?(type) }
        errors = false
      else
        flash[:notice] = 'Non-image file! Please only select the images of types `jpg`, `jpeg`, `png`.'
      end
    else
      errors = false
    end

    if errors
      redirect_to action: 'new'
      flash[:notice]
    end

    unless errors
      temp = course_params
      if course_params[:imagepath]
        temp[:imagepath] = course_params[:imagepath].original_filename
      end

      @course = Course.new(temp)

      if @course.save
        if course_params[:imagepath]
          File.open(Rails.root.join('vendor', 'assets/images', course_params[:imagepath].original_filename), 'wb') do |file|
            file.write(course_params[:imagepath].read)
          end
        end

        @course = Course.order('created_at').last
        if course_params[:categories]
          course_params[:categories].each do |category_id|
            category = Category.find category_id
            @course.categories << category
          end
        end

        if course_params[:locations]
          course_params[:locations].each do |location_id|
            location = Location.find location_id
            @course.locations << location
          end
        end

        redirect_to controller: 'users', action: 'show', id: session[:user_id]
        flash[:success] = 'Your course has been created successfully. Check it out now!'
      else
        redirect_to action: 'new'
        flash[:notice] = 'Server went wrong... Please try again later!'
      end
    end
  end

  # PATCH/PUT /courses/1
  # PATCH/PUT /courses/1.json
  def update
    errors = true
    filetypes = ['jpg', 'png', 'jpeg']
    if course_params[:title].length < 10 || course_params[:title].strip.empty?
      flash[:notice] = 'Course Title was either blank or too short. Required 10 or more letters long.'
    elsif course_params[:prerequisite].strip.empty?
      course_params[:prerequisite] = nil
    elsif course_params[:prerequisite].strip.length < 5
      flash[:notice] = 'Prerequisite was over abbreviated! Please make it meaningful to general visitors.'
    elsif course_params[:imagepath]
      if filetypes.any? { |type| course_params[:imagepath].original_filename.include?(type) }
        errors = false
      else
        flash[:notice] = 'Non-image file! Please only select the images of types `jpg`, `jpeg`, `png`.'
      end
    else
      errors = false
    end

    if errors
      redirect_to action: 'edit'
      flash[:notice]
    end

    unless errors
      temp = course_params
      if course_params[:imagepath]
        temp[:imagepath] = course_params[:imagepath].original_filename
      end

      if @course.update(temp)
        if course_params[:imagepath]
          File.open(Rails.root.join('vendor', 'assets/images', course_params[:imagepath].original_filename), 'wb') do |file|
            file.write(course_params[:imagepath].read)
          end
        end

        redirect_to controller: 'users', action: 'show', id: session[:user_id]
        flash[:success] = 'Your course has been created successfully. Check it out now!'
      else
        redirect_to action: 'edit'
        flash[:notice] = 'Server went wrong... Please try again later!'
      end
    end
  end

  # DELETE /courses/1
  # DELETE /courses/1.json
  def destroy
    @course.destroy

    redirect_to controller: 'admin', action: 'courses'
    flash[:success] = 'The course has been deleted successfully.'
  end

  def reset
    @course = Course.find params[:id]
    if @course.like.zero? && @course.dislike.zero?
      redirect_to controller: 'admin', action: 'courses'
      flash[:notice] = 'The selected course currently has no votes to reset.'
    else
      data = Hash.new
      data[:title] = @course.title
      data[:prerequisite] = @course.prerequisite
      data[:madeon] = @course.madeon
      data[:like] = 0
      data[:dislike] = 0
      data[:imagepath] = @course.imagepath
      data[:user_id] = @course.user_id

      if @course.update data
        redirect_to controller: 'admin', action: 'courses'
        flash[:success] = 'The selected course\'s votes has been reset successfully.'
      else
        redirect_to controller: 'admin', action: 'courses'
        flash[:notice] = 'Server went wrong... Please try again later'
      end
    end
  end

  private
  def get_user
    @users = User.all
  end

  # Use callbacks to share common setup or constraints between actions.
  def set_course
    @course = Course.find(params[:id])
  end

  # Never trust parameters from the scary internet, only allow the white list through.
  def course_params
    params.require(:course).permit(:title, :prerequisite, :madeon, :like, :dislike, :imagepath, :user_id, :description)
  end
end
