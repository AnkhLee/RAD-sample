require 'digest'
require 'bcrypt'
class UsersController < ApplicationController
  before_action :set_user, only: [:show, :edit, :update, :destroy]

  # GET /users
  # GET /users.json
  def index
    @users = User.all
  end

  # GET /users/1
  # GET /users/1.json
  def show
  end

  # GET /users/new
  def new
    @user = User.new
  end

  # GET /users/1/edit
  def edit
  end

  # POST /users
  # POST /users.json
  def create
    errors = true
    if user_params[:name].length < 5 || user_params[:name].strip.empty? || user_params[:name].strip.length < 5
      flash[:notice] = 'Name is blank or too short. Required 4 or more letters long.'
    elsif user_params[:name] !~ /^[[:alpha:][:blank:]]+/
      flash[:notice] = 'Name should only contain letters and spaces, no special characters or numbers.'
    elsif user_params[:email].exclude?('rmit.edu.au')
      flash[:notice] = 'Registration only open for RMIT Staff Emails.'
    elsif user_params[:password] !~ /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9]).{8,}$/
      flash[:notice] = 'Password must be more than 8 characters long.'
      flash[:notice] = 'Pasword must contain at least 1 lowercase letter, 1 uppercase letter and 1 number.'
    else
      errors = false
    end

    unless errors
      user_params[:password] = Digest::SHA1.hexdigest user_params[:password].to_s
      @user = User.new(user_params)

      if @user.save
        redirect_to controller: 'sessions', action: 'new'
        flash[:success] = 'Registration was successful. Please log-in now!'
      else
        redirect_to action: 'new'
        flash[:notice] = 'Server went wrong... Please try again later!'
      end
    end

    if errors
      redirect_to action: 'new'
      flash[:notice]
    end
  end

  # PATCH/PUT /users/1
  # PATCH/PUT /users/1.json
  def update
    errors = true
    if user_params[:name].length < 5 || user_params[:name].strip.empty?
      flash[:notice] = 'Name is blank or too short. Required 4 or more letters long.'
    elsif user_params[:name] !~ /^[[:alpha:][:blank:]]+/
      flash[:notice] = 'Name should only contain letters and spaces, no special characters or numbers.'
    elsif user_params[:email].exclude?('rmit.edu.au')
      flash[:notice] = 'Registration only open for RMIT Staff Emails.'
    elsif user_params[:password] !~ /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9]).{8,}$/
      flash[:notice] = 'Password must be more than 8 characters long.'
      flash[:notice] = 'Pasword must contain at least 1 lowercase letter, 1 uppercase letter and 1 number.'
    else
      errors = false
    end

    if errors
      redirect_to action: 'edit'
      flash[:notice]
    end

    unless errors
      user_params[:password] = Digest::SHA1.hexdigest user_params[:password].to_s

      if @user.update(user_params)
        redirect_to controller: 'users', action: 'show', id: session[:user_id]
        flash[:success] = 'Oohh! Your Profile has been updated successfully. Get back to your stuffs here.'
      else
        redirect_to action: 'edit', id: session[:user_id]
        flash[:notice] = 'Server went wrong... Please try again later!'
      end
    end
  end

  # DELETE /users/1
  # DELETE /users/1.json
  def destroy
    @user.destroy

    redirect_to controller: 'admin', action: 'coordinators'
    flash[:success] = 'The coordinator has been deleted successfully.'
  end

  private
  # Use callbacks to share common setup or constraints between actions.
  def set_user
    @user = User.find(params[:id])
  end

  # Never trust parameters from the scary internet, only allow the white list through.
  def user_params
    params.require(:user).permit(:name, :email, :password)
  end
end
