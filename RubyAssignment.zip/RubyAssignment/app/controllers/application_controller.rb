class ApplicationController < ActionController::Base
  protect_from_forgery with: :exception

  add_flash_types :success, :cnotice, :csuccess
  before_filter :prepareData
  helper_method :newContact

  private

  def newContact
    Contact.new
  end

  def prepareData
    @current_user ||= User.find(session[:user_id]) if session[:user_id] && session[:user_id] != 0
    @locations = Location.all
    @categories = Category.all
  end
end
