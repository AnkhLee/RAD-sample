class ContactsController < ApplicationController
  def create
    errors = true
    if contact_params[:name].length < 5 || contact_params[:name].strip.empty? || contact_params[:name].strip.length < 5
      flash[:cnotice] = 'Name is blank or too short.'
    elsif contact_params[:name] !~ /^[[:alpha:][:blank:]]+/
      flash[:cnotice] = 'Name only contains letters and spaces.'
    elsif contact_params[:email].exclude?('rmit.edu.au')
      flash[:cnotice] = 'Please use your RMIT email address.'
    elsif contact_params[:message].length < 10 || contact_params[:message].strip.empty? || contact_params[:message].strip.length < 10
      flash[:cnotice] = 'Message is blank or too short.'
    else
      errors = false
    end

    if errors
      redirect_to '/'
      flash[:cnotice]
    end

    unless errors
      @contact = Contact.new(contact_params)
      if @contact.save
        ApplicationMailer.contact_mail(@contact).deliver
        redirect_to '/'
        flash[:csuccess] = 'Your message has been sent.'
      else
        redirect_to '/'
        flash[:cnotice] = 'Server went wrong. Try again later!'
      end
    end
  end

  def destroy
    email = Contact.find params[:id]
    email.destroy

    redirect_to controller: 'admin', action: 'emails'
    flash[:csuccess] = 'Email has been deleted successfully.'
  end

  private

  def contact_params
    params.require(:contact).permit(:name, :email, :message)
  end
end