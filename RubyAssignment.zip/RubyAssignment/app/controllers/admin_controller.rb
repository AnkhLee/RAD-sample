class AdminController < ApplicationController
  def emails
    @emails = Contact.all
  end

  def courses
    @courses = Course.all
  end

  def coordinators
    @coordinators = User.all
  end
end