class Course < ApplicationRecord
  belongs_to :user

  has_and_belongs_to_many :locations
  has_and_belongs_to_many :categories

  has_many :courses_users
  has_many :cvotes, through: :courses_users, source: :user

  def created
    @now = Time.now
    @elapse = @now - madeon

    if @elapse < 60
      @label = @elapse.to_s + ' secs ago'
    elsif @elapse < 60*60
      @label = 'About ' + (@elapse/60).to_s + ' mins ago'
    elsif @elapse < 86400
      hh = @elapse/3600

      @label = 'About ' + hh.floor.to_s + ' hours ago'
    else
      dd = @elapse/86400

      @label = 'About ' + dd.floor.to_s + ' days ago'
    end
  end
end
