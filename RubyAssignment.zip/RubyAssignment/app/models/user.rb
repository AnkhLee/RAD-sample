require 'digest'
require 'digest/sha2'
require 'bcrypt'

class User < ApplicationRecord
  has_many :courses, dependent: :destroy
  has_many :courses_users
  has_many :uvotes, through: :courses_users, source: :course
  has_secure_password

  def gravatar_for(user, options = { size: 240 })
    gravatar_id = Digest::MD5.hexdigest user.id.to_s
    size = options[:size]
    gravatar_url = "https://secure.gravatar.com/avatar/#{gravatar_id}?s=#{size}"
  end
end
