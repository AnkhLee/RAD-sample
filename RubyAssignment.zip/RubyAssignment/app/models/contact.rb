class Contact < ApplicationRecord
end