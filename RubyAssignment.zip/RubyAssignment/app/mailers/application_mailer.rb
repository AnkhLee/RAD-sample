class ApplicationMailer < ActionMailer::Base
  default to: 'admin@sciencecourses.rmit.edu.au'
  layout 'mailer'

  def contact_mail mail
    @mail = mail
    mail(from: @mail.email, subject: '[General Enquiry] ' << @mail.name, body: @mail.message)
  end
end
