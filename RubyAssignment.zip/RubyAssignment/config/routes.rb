Rails.application.routes.draw do
  root :to => 'home#index'
  get 'home/index'

  resources :locations
  resources :categories
  resources :courses
  resources :users
  resources :sessions

  get '/login' => 'sessions#new'
  post '/login' => 'sessions#login'
  get '/destroy' => 'sessions#destroy'

  post 'contacts/create' => 'contacts#create'
  get 'contacts/destroy' => 'contacts#destroy'

  get 'admin/emails' => 'admin#emails'
  get 'admin/courses' => 'admin#courses'
  get 'admin/coordinators' => 'admin#coordinators'

  get 'courses/:id/reset' => 'courses#reset'

  get 'votes/:id/upvote' => 'votes#upvote'
  get 'votes/:id/downvote' => 'votes#downvote'

  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
